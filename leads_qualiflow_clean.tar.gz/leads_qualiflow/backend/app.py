"""Leads QualiFlow - Backend API Server
Handles questionnaire submissions and generates documents."""

import os
import json
import uuid
from datetime import datetime
from flask import Flask, request, jsonify, render_template_string, send_file
from flask_cors import CORS
from generator import DocumentGenerator

app = Flask(__name__)
CORS(app)

# Store generated documents in memory (use a database in production)
documents_store = {}

# HTML template for document viewer
DOC_VIEWER = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document - Leads QualiFlow</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Courier New', monospace; background: #1a1a2e; color: #e0e0e0; padding: 2rem; }
        pre { background: #0d0d1a; padding: 2rem; border-radius: 8px; overflow-x: auto; white-space: pre-wrap; font-size: 14px; line-height: 1.6; border: 1px solid #333; }
        h1 { color: #00a86b; margin-bottom: 1rem; font-family: Arial, sans-serif; }
        .actions { margin: 2rem 0; display: flex; gap: 1rem; flex-wrap: wrap; }
        .btn { padding: 0.8rem 1.5rem; border-radius: 4px; text-decoration: none; font-weight: bold; cursor: pointer; border: none; }
        .btn-primary { background: #0057b7; color: white; }
        .btn-primary:hover { background: #003d80; }
        .btn-success { background: #00a86b; color: white; }
        .btn-success:hover { background: #007a4e; }
        .nav { margin-bottom: 2rem; }
        .nav a { color: #00a86b; text-decoration: none; margin-right: 1rem; }
        .nav a:hover { text-decoration: underline; }
        .badge { background: #00a86b; color: white; padding: 0.25rem 0.75rem; border-radius: 4px; font-size: 0.8rem; }
        .meta { margin-bottom: 2rem; color: #888; font-family: Arial, sans-serif; }
    </style>
</head>
<body>
    <div class="nav">
        <a href="/">&larr; Back to API</a>
        <span class="badge">{{ business_name }}</span>
    </div>
    <h1>Chatbot Configuration</h1>
    <div class="meta">Generated: {{ generated_at }}</div>
    <div class="actions">
        <a href="/download/{{ doc_id }}/chatbot" class="btn btn-primary">Download Chatbot Config</a>
        <a href="/download/{{ doc_id }}/scoring" class="btn btn-success">Download Scoring Matrix</a>
        <a href="/download/{{ doc_id }}/clone" class="btn btn-primary">Download AI Clone Brief</a>
        <a href="/download/{{ doc_id }}/all" class="btn btn-success">Download All (.txt)</a>
    </div>
    <pre>{{ doc_content }}</pre>
</body>
</html>"""


@app.route('/')
def home():
    return jsonify({
        'service': 'Leads QualiFlow Document Generation API',
        'version': '1.0.0',
        'endpoints': {
            'POST /api/generate': 'Submit questionnaire answers, get generated documents',
            'GET /api/doc/<id>': 'View generated documents',
            'GET /download/<id>/<type>': 'Download a specific document type'
        },
        'status': 'running'
    })


@app.route('/api/generate', methods=['POST'])
def generate():
    """Receive questionnaire answers and generate documents."""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Validate required fields
        required = ['business_name', 'industry']
        missing = [f for f in required if not data.get(f)]
        if missing:
            return jsonify({'error': f'Missing required fields: {", ".join(missing)}'}), 400
        
        # Generate documents
        gen = DocumentGenerator(data)
        docs = gen.generate_all()
        
        # Store with unique ID
        doc_id = str(uuid.uuid4())[:8]
        documents_store[doc_id] = {
            'docs': docs,
            'answers': data,
            'created_at': datetime.now().isoformat()
        }
        
        return jsonify({
            'success': True,
            'doc_id': doc_id,
            'business_name': data.get('business_name'),
            'view_url': f'/api/doc/{doc_id}',
            'download_urls': {
                'chatbot': f'/download/{doc_id}/chatbot',
                'scoring': f'/download/{doc_id}/scoring',
                'clone': f'/download/{doc_id}/clone',
                'all': f'/download/{doc_id}/all'
            }
        }), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/doc/<doc_id>')
def view_doc(doc_id):
    """View generated documents in browser."""
    if doc_id not in documents_store:
        return render_template_string("""
            <h1>Document not found</h1>
            <p>The document ID "{{ doc_id }}" does not exist or has expired.</p>
            <a href="/">Back to API</a>
        """, doc_id=doc_id), 404
    
    entry = documents_store[doc_id]
    docs = entry['docs']
    
    return render_template_string(
        DOC_VIEWER,
        doc_id=doc_id,
        business_name=docs['business_name'],
        generated_at=docs['generated_at'],
        doc_content=docs['chatbot_config']
    )


@app.route('/download/<doc_id>/<doc_type>')
def download(doc_id, doc_type):
    """Download a specific document as a text file."""
    if doc_id not in documents_store:
        return jsonify({'error': 'Document not found'}), 404
    
    entry = documents_store[doc_id]
    docs = entry['docs']
    business = docs['business_name']
    
    doc_map = {
        'chatbot': ('chatbot_config', f'{business}-Chatbot-Config.txt'),
        'scoring': ('scoring_criteria', f'{business}-Scoring-Matrix.txt'),
        'clone': ('ai_clone_brief', f'{business}-AI-Clone-Brief.txt'),
    }
    
    if doc_type == 'all':
        # Combine all documents
        content = f"""Leads QualiFlow - Generated Documents
Business: {business}
Generated: {docs['generated_at']}
{'='*60}

{docs['chatbot_config']}

{docs['scoring_criteria']}

{docs['ai_clone_brief']}
"""
        filename = f'{business}-All-Docs.txt'
    elif doc_type in doc_map:
        key, filename = doc_map[doc_type]
        content = docs[key]
    else:
        return jsonify({'error': f'Invalid document type: {doc_type}'}), 400
    
    # Save to temporary file and send
    import tempfile
    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt', encoding='utf-8') as f:
        f.write(content)
        temp_path = f.name
    
    return send_file(
        temp_path,
        as_attachment=True,
        download_name=filename,
        mimetype='text/plain'
    )


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
